function calcularSoma(){
    let num1 = parseFloat(document.getElementById("numero1").value);
    let num2 = parseFloat(document.getElementById("numero2").value);

    if(!isNaN(num1)&&!isNaN(num2)){
        let soma = num1 + num2;
        document.getElementById("resposta").innerText=soma;
    }
    else{
        window.alert("Número(s) inválido(s).");
    }
}

function resetar(){
    document.getElementById("numero1").value = "";
    document.getElementById("numero2").value = "";
    document.getElementById("resposta").innerText = "";
}