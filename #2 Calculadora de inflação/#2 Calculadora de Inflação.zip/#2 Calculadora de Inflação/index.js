function calcInflacao(){
    let anoInicio=parseFloat(document.getElementById("dataInicio").value);
    let anoTermino=parseFloat(document.getElementById("dataTermino").value);
    let valorInicio=parseFloat(document.getElementById("valorInicio").value);
    let inflacaoAno=parseFloat(document.getElementById("inflacaoAno").value);

    if(!isNaN(anoInicio)&&!isNaN(anoTermino)&&!isNaN(valorInicio)&&!isNaN(inflacaoAno)){
        if(anoTermino > anoInicio){
            let periodo = anoTermino - anoInicio;
            let porc = inflacaoAno/100;
            let index = 1 + porc;//indice inflacionario
            let valorInflacionado = valorInicio * Math.pow(index, periodo);

            document.getElementById("periodo").innerText = "Período: " + periodo + " Anos.";
            document.getElementById("valorTermino").innerText = "Valor no término: " + valorInflacionado.toFixed(2);
        }
        else{
            window.alert("O ano de término deve ser posterior ao de início.")
        }
    }else{
        window.alert("Dados inválidos.")
    }
}

function resetarTudo(){
    document.getElementById("dataInicio").value = "";
    document.getElementById("dataTermino").value = "";
    document.getElementById("valorInicio").value = "";
    document.getElementById("inflacaoAno").value = "";
    document.getElementById("periodo").innerText = "Período: ";
    document.getElementById("valorTermino").innerText = "Valor no término: ";
}

